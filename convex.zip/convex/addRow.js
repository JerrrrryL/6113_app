import { query } from "./_generated/server";

export default query(async ({ db }) => {
	const tup = {
		A: 5,
		B: 6,
		C: 7,
	};
	await db.insert("simple", tup);
	return "done";
});
